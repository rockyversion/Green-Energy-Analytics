from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# Load model and scaler
model = joblib.load("rf_model.pkl")
scaler = joblib.load("scaler.pkl")

FEATURES = [
    'temperature',
    'humidity',
    'wind_speed',
    'solar_radiation',
    'cloud_cover',
    'pressure',
    'zenith_angle',
    'azimuth_angle'
]

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    error = None

    if request.method == "POST":
        try:
            values = []

            for feature in FEATURES:
                val = request.form.get(feature)
                if val is None or val.strip() == "":
                    raise ValueError(f"Missing value for {feature}")
                values.append(float(val))

            # Physical constraint
            if values[3] <= 0:
                prediction = 0.0
            else:
                X = np.array(values).reshape(1, -1)
                X_scaled = scaler.transform(X)
                prediction = round(float(model.predict(X_scaled)[0]), 2)

        except Exception as e:
            error = str(e)

    return render_template("index.html", prediction=prediction, error=error)

if __name__ == "__main__":
    app.run(debug=True)